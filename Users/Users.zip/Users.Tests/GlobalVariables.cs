﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Users.Tests
{
    class GlobalVariables
    {
        private string _pepper = "z0AYHca$nk@5Lhr:vq7y|6e4P61&^U71coEl?dhyT$u8l|$LcG";
        public string Pepper ()
        {
            return _pepper;
        }
    }
}
